"""Local Short Studio application."""

